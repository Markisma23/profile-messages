<div class="row border-bottom" style="background: silver;">
    <nav class="navbar navbar-static-top" role="navigation" style="margin-bottom: 0" style="background: silver;">
        <div class="navbar-header"> <a class="navbar-minimalize minimalize-styl-2 btn btn-primary " style="background: silver;" href="#"><i class="fa fa-bars" style="background: silver;"></i> </a>
            
        </div>
        
    </nav>
</div>